#!/usr/bin/env bash
set -euo pipefail

# Run this from project root on a machine with Flutter installed.
flutter create --platforms=android,windows,linux .
flutter pub get

python3 - <<'PY'
from pathlib import Path

manifest = Path('android/app/src/main/AndroidManifest.xml')
if manifest.exists():
    s = manifest.read_text(encoding='utf-8')
    root = '<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
    if 'android.permission.INTERNET' not in s:
        s = s.replace(root, root + '\n    <uses-permission android:name="android.permission.INTERNET"/>')
    # Needed by Android 11+ TTS service discovery.
    if 'android.intent.action.TTS_SERVICE' not in s:
        queries = '''\n    <queries>\n        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE" />\n        </intent>\n    </queries>\n'''
        s = s.replace('<application', queries + '    <application', 1)
    # Development LAN bridge uses HTTP. Keep PC Brain token-protected on LAN.
    if 'android:usesCleartextTraffic=' not in s:
        s = s.replace('<application', '<application android:usesCleartextTraffic="true"', 1)
    manifest.write_text(s, encoding='utf-8')

# three_js and flutter_tts require Android minSdk >=21. Modern Flutter templates
# generally satisfy this; patch common Gradle formats if they are lower.
for path in [Path('android/app/build.gradle'), Path('android/app/build.gradle.kts')]:
    if not path.exists():
        continue
    s = path.read_text(encoding='utf-8')
    s = s.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 21')
    s = s.replace('minSdk = flutter.minSdkVersion', 'minSdk = 21')
    path.write_text(s, encoding='utf-8')
PY

echo "Flutter platform files created. Run: flutter run"
