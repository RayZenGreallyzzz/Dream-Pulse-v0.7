#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK not found. Install Flutter 3.24+ first."
  exit 1
fi

flutter create --platforms=android --org com.dreampulse .
flutter pub get

MANIFEST="android/app/src/main/AndroidManifest.xml"
python3 - "$MANIFEST" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text()
for perm in [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '<uses-permission android:name="android.permission.BLUETOOTH" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />',
    '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />',
]:
    if perm not in s:
        s=s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
                    '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    '+perm)
if '<queries>' not in s:
    query='''\n    <queries>\n        <intent>\n            <action android:name="android.speech.RecognitionService" />\n        </intent>\n    </queries>'''
    s=s.replace('<application', query+'\n    <application')
if 'android:largeHeap=' not in s:
    s=s.replace('<application', '<application android:largeHeap="true" android:usesCleartextTraffic="true"')
elif 'android:usesCleartextTraffic=' not in s:
    s=s.replace('android:largeHeap="true"', 'android:largeHeap="true" android:usesCleartextTraffic="true"')
p.write_text(s)
PY

# llama_flutter_android requires API 26+. Flutter currently generates Kotlin Gradle files.
if [ -f android/app/build.gradle.kts ]; then
  python3 - <<'PY2'
from pathlib import Path
p=Path('android/app/build.gradle.kts')
s=p.read_text()
s=s.replace('minSdk = flutter.minSdkVersion', 'minSdk = 26')
p.write_text(s)
PY2
elif [ -f android/app/build.gradle ]; then
  python3 - <<'PY2'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
s=s.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 26')
p.write_text(s)
PY2
fi

cat > android/app/proguard-rules.pro <<'RULES'
-keep class com.write4me.llama_flutter_android.** { *; }
-keep class kotlin.jvm.functions.Function1
-keepclassmembers class * implements kotlin.jvm.functions.Function1 {
    public java.lang.Object invoke(java.lang.Object);
}
-keepclasseswithmembernames class * {
    native <methods>;
}
RULES

echo "Android bootstrap complete. Next: flutter run"
