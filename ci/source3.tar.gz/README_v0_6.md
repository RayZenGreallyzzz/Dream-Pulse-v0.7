# Dream Pulse v0.6 — Avatar Assistant

Dream Pulse v0.6 turns the v0.5 Living World into an actual assistant shell for Android and desktop.

The app now has three surfaces:

1. **Assistant** — chat with LOCAL / HYBRID / ONLINE execution modes.
2. **Avatar** — load a rigged GLB, inspect its skeleton/animations, render it locally, animate it, and speak with TTS-driven mouth motion.
3. **Pulse** — the existing multi-CORE ring/world diagnostics.

## New in v0.6

### Avatar Core

- pick a local `.glb` on Android/desktop
- render the GLB with `three_js`
- play embedded animation clips
- auto-detect common roles such as Idle / Walk / Run / Talk / Attack / Wave
- inspect skeletons, joint count, animation names, morph target names, jaw/head/eye bone candidates
- lip-sync priority:
  1. mouth/viseme morph target
  2. jaw bone
  3. embedded Talk animation
  4. procedural fallback
- TTS through `flutter_tts`
- word-synchronous mouth pulses while speaking
- avatar upload is stored only inside Dream Pulse runtime
- max avatar size defaults to 100 MB (`DREAM_MAX_AVATAR_MB`)

### Assistant Agent

Modes:

- `LOCAL`: local LLM + local Dream Pulse memory/tools; no web tool
- `HYBRID`: local work; web search is available only when the user enables it
- `ONLINE`: requires web-search permission and an installed web provider

The bounded agent tool loop can request only:

- `web_search`
- `workspace_list`
- `workspace_read`
- `workspace_write` (only when the user enables write permission for that task)
- `avatar_inspect`

There is deliberately **no shell tool**, no arbitrary command execution, no file delete tool, no privilege escalation, and no self-modification tool.

### Internet search

PC search is optional and disabled by default.

```bash
pip install -r pc_brain/requirements.txt
export DREAM_WEB_SEARCH=1
```

The current optional provider is `ddgs`.

Web-derived answers still pass through the Critic. They are not copied directly into the old generic memory table; they remain local CORE proposals and need the multi-CORE verification path before becoming global knowledge.

### Local workspace

Dream Pulse gets a sandbox at:

```text
pc_brain/runtime/workspace/
```

The assistant can list and read that workspace. Writing requires explicit per-task approval from the UI. Relative paths are resolved and path traversal outside the workspace is blocked. Permanent delete is not implemented.

### Living multi-CORE world

All v0.5 behavior remains:

- CORE specialization
- automatic routing
- local proposals
- independent CORE verification
- global verified knowledge
- WORLD_SYNC
- bounded splitting
- equal inherited knowledge at split time
- divergent child specializations and later experience
- maintenance/quarantine

## PC setup

Python 3.10+ is recommended.

```bash
cd pc_brain
pip install -r requirements.txt
```

For a real local LLM, run Ollama and configure:

```bash
export DREAM_LLM_PROVIDER=ollama
export DREAM_OLLAMA_URL=http://127.0.0.1:11434
export DREAM_OLLAMA_MODEL=qwen3:4b
python server.py
```

Without Ollama, the safe stub keeps the server testable but Critic refuses to assimilate its placeholder answers.

## Internet permission

Off by default:

```bash
DREAM_WEB_SEARCH=0
```

Enable explicitly:

```bash
DREAM_WEB_SEARCH=1
```

`ONLINE` mode fails closed if web search is not enabled/installed.

## Android ↔ PC

Localhost is the safe default. To let Android reach the PC on the LAN, bind the PC brain to the LAN and set a strong token:

```bash
DREAM_HOST=0.0.0.0
DREAM_BRIDGE_TOKEN=<long-random-token>
python server.py
```

The server refuses non-loopback binding without a token.

## Flutter setup

The source tree intentionally does not contain generated platform folders. On a machine with Flutter installed:

```bash
./scripts/bootstrap_flutter.sh
flutter run
```

Core Flutter dependencies in v0.6:

```yaml
three_js: ^0.3.0
file_picker: ^11.0.3
flutter_tts: ^4.2.5
```

The project keeps Dart `>=3.4.0`, so it uses file_picker 11.x rather than the newer 13.x line that requires a newer Dart SDK.

## Tests

From `pc_brain/`:

```bash
python test_smoke.py
python test_world.py
python test_life.py
python test_avatar.py
python test_workspace.py
python test_agent.py
```

For full HTTP integration, start the server and run:

```bash
python test_http.py
```

## Important limitation

The Python/HTTP side is executable and tested in the build environment. The build environment does not have Flutter/Dart installed, so the Android/Windows UI source could not be compiled here. It is written against the documented APIs of `three_js`, `file_picker`, and `flutter_tts`, but the first real Flutter build should be treated as the platform integration pass.

## v0.6 architecture

```text
                    USER
                     |
               text / voice
                     |
          +----------v----------+
          |  ASSISTANT SHELL    |
          +----------+----------+
                     |
       +-------------+-------------+
       |             |             |
     LOCAL         HYBRID        ONLINE
       |             |             |
       +-------------+-------------+
                     |
                AUTO ROUTER
                     |
              DREAM PULSE WORLD
          +----------+----------+
          |          |          |
        CODE        3D       RESEARCH ...
          |          |          |
       Workers    Avatar     Web worker
          |          |          |
       Critic <------+----------+
          |
        CORE
          |
     verified memory

Avatar path:
GLB -> skeleton/animation inspection -> three_js renderer
    -> TTS -> Talk animation + morph/jaw lip motion
```
